        <?php
$path = $_SERVER['REQUEST_URI'];
?>
        <div class="onlineTop">
            <h1>Advisory Services</h1>
            <p class="subTxt">Business/Finance Transformation
                Improving the effectiveness in Financial planning processes to generating
                ingenious functions with smart
                workflows - proficient in identifying, relating and evaluating data to
                uncover profound understandings
                that can apprise intelligent decisions. We engage with clients to advise and
                manage end-to-end
                processes.</p>
            <div class="tabSec">
                <!-- <ul>
        <li href="incorporate-your-business.php">
        <a href="incorporate-your-business.php"><img src="assets/img/icons/incorporate/building.png"/> Private Limited Company</a></li>
        <li><a href="one_person_company.php"><img src="assets/img/icons/incorporate/oneperson-company.png"/> One Person Company</a></li>
        <li><a href="limited_liability_partnership.php"><img src="assets/img/icons/incorporate/limited-partnership.png"/> Limited Liability Partnership</a></li>
        <li><a href="gst_compliant.php"><img src="assets/img/icons/incorporate/gst.png"/> GST Compliant Private Limited</a></li>
        <li><a href="ngo_company_registration.php"><img src="assets/img/icons/incorporate/ngo.png"/> NGO Registration</a></li>
        <li><a href="partnership_firm_registration.php"><img src="assets/img/icons/incorporate/partner-firm.png"/> Partnership Firm Registration</a></li>
        <li><a href="sole_proprietorship.php"><img src="assets/img/icons/incorporate/single-firm.png"/> Sole Proprietorship</a></li>
    </ul> -->
                <ul>
                    <li><a href="#consulting" onclick="clickToScroll('consulting')"><img
                                src="assets/img/icons/govt/earn-money.png" />Consulting Business</a></li>
                    <li><a href="#risk" onclick="clickToScroll('risk')"><img src="assets/img/icons/govt/tax.png" /> Risk
                            and Governance</a></li>
                    <li><a href="#it-consult" onclick="clickToScroll('it-consult')"><img
                                src="assets/img/icons/govt/advanced_tax.png" />IT Consulting </a></li>
                    <li><a href="#valuation" onclick="clickToScroll('valuation')"><img
                                src="assets/img/icons/govt/pan.png" /> Due Diligence & Valuation</a></li>
                    <li><a href="#audit" onclick="clickToScroll('audit')"><img
                                src="assets/img/icons/govt/import.png" />Audit and Tax</a></li>
                </ul>
            </div>
        </div>





        <?php /*if(strpos($path,'incorporate-your-business.php')>0){ ?> class="active" <?php } */ ?>