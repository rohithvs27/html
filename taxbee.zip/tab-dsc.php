        
<?php
$path = $_SERVER['REQUEST_URI'];
?>
<div class="tabSec">
    <ul>
    <!-- <li <?php /* if(strpos($path,'dsc_for_indian_class2.php')>0){ ?>  class="active" <?php } */?> href="dsc_for_indian_class2.php">
    <a href="dsc_for_indian_class2.php"><img src="assets/img/icons/dsc/dsc_class2.png"/> DSC for Indian Citizens (Class 2)</a></li> -->
        <li><a href="dsc_for_indian.php"><img src="assets/img/icons/dsc/dsc_class3.png"/> Digital Signature - Class 3</a></li>
        <li><a href="dsc_for_nri.php"><img src="assets/img/icons/dsc/dsc_for_nri.png"/> DSC for Foreign citizens</a></li>
    </ul>
</div>