        
<?php
$path = $_SERVER['REQUEST_URI'];
?>
<div class="tabSec">
    <ul>
        <li><a href="change_company_name.php"><img src="assets/img/icons/legel/company.png"/> Change Company Name</a></li>
        <li><a href="change_registered_office.php"><img src="assets/img/icons/legel/register_office.png"/> Change Registered Office</a></li>
        <li><a href="appoint_director.php"><img src="assets/img/icons/govt/earn-money.png"/> Appoint a Director</a></li>
        <li><a href="resignation_of_director.php"><img src="assets/img/icons/govt/earn-money.png"/> Resignation of Director</a></li>
        <li><a href="authorised_share_capital.php"><img src="assets/img/icons/legel/share_capital.png"/> Increase of Authorised Share Capital</a></li>
        <li><a href="memorandum_of_association.php"><img src="assets/img/icons/legel/association.png"/> Changes in Memorandum of Association</a></li>
        <li><a href="commencement_of_business.php"><img src="assets/img/icons/legel/limited_partnership.png"/> Declaration for Commencement of Business</a></li>
        <li><a href="legal_documents_review.php"><img src="assets/img/icons/legel/legel_document.png"/> Legal Documents Review</a></li>
        <li><a href="form_inc_22a.php"><img src="assets/img/icons/legel/form.png"/> Form INC 22A</a></li>
        <li><a href="legal_drafting.php"><img src="assets/img/icons/legel/draft.png"/> Legal Drafting</a></li>
    </ul>
</div>